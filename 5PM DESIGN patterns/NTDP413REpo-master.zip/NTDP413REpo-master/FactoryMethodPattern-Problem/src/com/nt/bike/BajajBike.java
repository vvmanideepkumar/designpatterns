package com.nt.bike;

public interface BajajBike {
   public void drive();
}
