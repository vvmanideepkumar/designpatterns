package com.nt.bike;

public class BajajDiscover implements BajajBike {

	@Override
	public void drive() {
		System.out.println("BajajDiscover.drive()---->Driving Bajaj discover bike");
	}

}
