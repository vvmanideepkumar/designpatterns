package com.nt.bike;

public class BajajPulsor implements BajajBike {

	@Override
	public void drive() {
		System.out.println("BajajPlusor.drive()---->Driving Bajaj pulsor bike");
	}

}
