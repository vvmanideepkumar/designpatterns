package com.nt.bike;

public class BajajPlatina implements BajajBike {

	@Override
	public void drive() {
		System.out.println("BajajPlatina.drive()---->Driving Bajaj platina bike");
	}

}
