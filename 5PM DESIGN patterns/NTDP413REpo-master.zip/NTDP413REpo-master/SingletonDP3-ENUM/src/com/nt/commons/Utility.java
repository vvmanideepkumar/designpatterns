package com.nt.commons;

import java.io.Serializable;

public interface Utility extends Cloneable{
	
	

}
