package com.nt.vehicle;

public interface Car {
     
     public void  roadTest();
}
