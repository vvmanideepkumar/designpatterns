package com.nt.tyre;

public class MRFTyre  implements Tyre {

	@Override
	public String info() {
		
		return "Tyres with good Road grip and for Speed";
	}

}
