package com.nt.tyre;

public class MechallinTyre  implements Tyre {

	@Override
	public String info() {
		
		return "Tyres with nyln  Road grip for smooth driver, comfort and for skid Protection";
	}

}
