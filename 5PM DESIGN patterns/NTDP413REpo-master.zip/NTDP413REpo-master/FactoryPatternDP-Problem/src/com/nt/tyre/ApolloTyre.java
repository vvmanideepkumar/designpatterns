package com.nt.tyre;

public class ApolloTyre  implements Tyre {

	@Override
	public String info() {
		
		return "Tyres with  Road grip and for long run";
	}

}
