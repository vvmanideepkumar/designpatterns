package com.nt.tyre;

public interface Tyre {
    public  String info();
}
