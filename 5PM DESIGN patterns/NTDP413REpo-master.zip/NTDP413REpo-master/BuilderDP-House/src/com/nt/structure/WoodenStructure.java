package com.nt.structure;

public class WoodenStructure implements Structure {

	@Override
	public String toString() {
		return "Wooden Structure";
	}

	
}
