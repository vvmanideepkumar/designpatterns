package com.nt.structure;

public class ConcreteAndSteelStructure implements Structure {

	@Override
	public String toString() {
		return "ConcreteAndSteelStructure";
	}

	
}
