package com.nt.structure;

public class IceStructure implements Structure {

	@Override
	public String toString() {
		return "Ice Structure";
	}

	
}
