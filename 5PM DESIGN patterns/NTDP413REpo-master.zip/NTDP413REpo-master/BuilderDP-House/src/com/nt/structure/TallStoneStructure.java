package com.nt.structure;

public class TallStoneStructure implements Structure {

	@Override
	public String toString() {
		return "TallStone Structure";
	}

	
}
