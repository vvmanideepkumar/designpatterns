package com.nt.structure;

public interface Structure {

}
