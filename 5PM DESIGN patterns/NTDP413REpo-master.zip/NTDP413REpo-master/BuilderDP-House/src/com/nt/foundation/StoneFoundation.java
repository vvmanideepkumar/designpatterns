package com.nt.foundation;

public class StoneFoundation implements Foundation {

	@Override
	public String toString() {
		return "StoneFoundation ";
	}
	
	

}
