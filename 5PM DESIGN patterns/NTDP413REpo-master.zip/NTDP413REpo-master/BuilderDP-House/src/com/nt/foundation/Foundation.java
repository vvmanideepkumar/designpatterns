package com.nt.foundation;

public interface Foundation {

}
