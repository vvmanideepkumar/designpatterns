package com.nt.foundation;

public class IceFoundation implements Foundation {

	@Override
	public String toString() {
		return "IceFoundation ";
	}
	
	

}
