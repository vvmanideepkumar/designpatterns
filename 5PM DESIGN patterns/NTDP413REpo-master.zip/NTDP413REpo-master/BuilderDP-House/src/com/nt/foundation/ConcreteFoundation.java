package com.nt.foundation;

public class ConcreteFoundation implements Foundation {

	@Override
	public String toString() {
		return "ConcreteFoundation";
	}
}
