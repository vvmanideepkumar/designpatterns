package com.nt.foundation;

public class WoodenFoundation implements Foundation {

	@Override
	public String toString() {
		return "WoodenFoundation ";
	}
	
	

}
