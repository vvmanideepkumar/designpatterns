package com.nt.roofing;

public class ConcreteSlabRoofing implements Roofing {

	@Override
	public String toString() {
		return "ConcreteSlabRoofing ";
	}
	
	

}
