package com.nt.roofing;

public class CementSheetsRoofing implements Roofing {

	@Override
	public String toString() {
		return "CementSheets Roofing ";
	}
	
	

}
