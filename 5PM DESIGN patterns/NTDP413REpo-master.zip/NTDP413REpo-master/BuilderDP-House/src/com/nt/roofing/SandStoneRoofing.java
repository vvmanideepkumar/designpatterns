package com.nt.roofing;

public class SandStoneRoofing implements Roofing {

	@Override
	public String toString() {
		return "Sand Stone Roofing ";
	}
	
	

}
