package com.nt.roofing;

public class SteelSheetRoofing implements Roofing {

	@Override
	public String toString() {
		return "SteelSheet Roofing ";
	}
	
	

}
