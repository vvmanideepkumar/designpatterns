package com.nt.roofing;

public class IceRoofing implements Roofing {

	@Override
	public String toString() {
		return "Ice Roofing ";
	}
	
	

}
