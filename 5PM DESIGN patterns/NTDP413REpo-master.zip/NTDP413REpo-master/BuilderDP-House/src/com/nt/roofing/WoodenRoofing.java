package com.nt.roofing;

public class WoodenRoofing implements Roofing {

	@Override
	public String toString() {
		return "Wooden Roofing ";
	}
	
	

}
