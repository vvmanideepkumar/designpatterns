package com.nt.interior;

public class TilesInterior implements Interior {
	@Override
	public String toString() {
	   return "Tiles Interior";
	}

}
