package com.nt.interior;

public class IceInterior implements Interior {
	@Override
	public String toString() {
	   return "Ice Interior";
	}

}
