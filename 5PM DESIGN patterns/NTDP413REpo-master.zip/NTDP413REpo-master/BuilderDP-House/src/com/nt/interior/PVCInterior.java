package com.nt.interior;

public class PVCInterior implements Interior {
	@Override
	public String toString() {
	   return "PVC Interior";
	}

}
