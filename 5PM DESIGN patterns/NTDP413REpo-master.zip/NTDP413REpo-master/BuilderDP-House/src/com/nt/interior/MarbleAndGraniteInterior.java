package com.nt.interior;

public class MarbleAndGraniteInterior implements Interior {
	@Override
	public String toString() {
	   return "MarbleAndGranite Interior";
	}

}
