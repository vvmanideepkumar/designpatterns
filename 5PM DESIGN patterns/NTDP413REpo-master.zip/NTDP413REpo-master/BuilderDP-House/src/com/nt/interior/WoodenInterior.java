package com.nt.interior;

public class WoodenInterior  implements Interior {

	@Override
	public String toString() {
		return "Wooden Interior ";
	}
	

}
