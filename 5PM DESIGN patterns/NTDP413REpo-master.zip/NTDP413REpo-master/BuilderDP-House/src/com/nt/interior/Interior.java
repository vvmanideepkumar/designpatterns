package com.nt.interior;

public interface Interior {

}
