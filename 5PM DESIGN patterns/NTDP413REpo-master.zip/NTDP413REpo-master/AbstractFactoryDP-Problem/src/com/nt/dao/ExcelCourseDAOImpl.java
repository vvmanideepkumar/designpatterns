package com.nt.dao;

public class ExcelCourseDAOImpl implements DAO {

	@Override
	public void insert() {
		System.out.println("ExcelCourseDAO:: inserting course details to Excel.......");

	}

}
