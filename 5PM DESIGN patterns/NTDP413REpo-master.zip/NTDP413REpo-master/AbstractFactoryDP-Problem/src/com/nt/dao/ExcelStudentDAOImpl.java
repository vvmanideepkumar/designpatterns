package com.nt.dao;

public class ExcelStudentDAOImpl implements DAO {

	@Override
	public void insert() {
		System.out.println("ExcelStudentDAO:: inserting student details to Excel.......");

	}

}
