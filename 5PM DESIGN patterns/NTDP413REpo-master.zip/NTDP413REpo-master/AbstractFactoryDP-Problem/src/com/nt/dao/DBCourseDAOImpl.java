package com.nt.dao;

public class DBCourseDAOImpl implements DAO {

	@Override
	public void insert() {
		System.out.println("DBCourseDAO:: inserting course details to DB.......");

	}

}
