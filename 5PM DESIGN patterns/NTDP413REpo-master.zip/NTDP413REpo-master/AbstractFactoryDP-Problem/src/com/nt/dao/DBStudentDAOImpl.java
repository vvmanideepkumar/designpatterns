package com.nt.dao;

public class DBStudentDAOImpl implements DAO {

	@Override
	public void insert() {
		System.out.println("DBStudentDAO:: inserting student details to DB.......");

	}

}
