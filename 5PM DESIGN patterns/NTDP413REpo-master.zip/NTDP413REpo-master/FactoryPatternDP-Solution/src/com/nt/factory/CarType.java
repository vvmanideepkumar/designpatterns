package com.nt.factory;

public interface CarType {
	String  TYPE_STANDARD="standard";
	String  TYPE_LUXORY="luxory";
	String  TYPE_SPORTS="sports";

}
